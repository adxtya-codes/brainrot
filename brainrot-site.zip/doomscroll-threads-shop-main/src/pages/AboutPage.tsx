
import React from 'react';

const AboutPage = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-3xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">About brainrot</h1>
          <p className="text-xl text-muted-foreground">
            Designed for doomscrollers.
          </p>
        </div>

        <div className="space-y-8">
          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Our Story</h2>
            <p className="text-muted-foreground leading-relaxed">
              Born from the depths of infinite scroll sessions and 3am existential crises, 
              brainrot is more than just a clothing brand—it's a lifestyle. We understand 
              the unique experience of being chronically online, terminally digital, and 
              aesthetically aware of the beautiful chaos that is modern existence.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Our Mission</h2>
            <p className="text-muted-foreground leading-relaxed">
              To create wearable art for the digital generation. Every piece is designed 
              with the understanding that sometimes the most profound statements come from 
              embracing the absurdity of our hyperconnected world.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Quality & Ethics</h2>
            <p className="text-muted-foreground leading-relaxed">
              All our pieces are made from premium organic cotton and produced ethically. 
              We believe in sustainable fashion that doesn't compromise on style or comfort. 
              Because even doomscrollers deserve quality basics.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold">Join the Community</h2>
            <p className="text-muted-foreground leading-relaxed">
              Connect with fellow digital nomads, meme enthusiasts, and existential explorers. 
              Follow us on all platforms for exclusive drops, behind-the-scenes content, 
              and a healthy dose of organized chaos.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
