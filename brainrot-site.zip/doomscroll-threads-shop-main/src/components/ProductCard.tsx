
import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useWishlist } from '@/contexts/WishlistContext';

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  onSale?: boolean;
  image: string;
  sizes: string[];
  category?: string;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { isInWishlist, toggleItem } = useWishlist();

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.preventDefault();
    toggleItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image
    });
  };

  return (
    <Link to={`/product/${product.id}`} className="group block">
      <div className="relative overflow-hidden bg-muted/30 aspect-square mb-4">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Sale Badge */}
        {product.onSale && (
          <Badge 
            variant="default" 
            className="absolute top-2 left-2 bg-primary text-primary-foreground text-xs font-medium"
          >
            Sale
          </Badge>
        )}

        {/* Wishlist Button */}
        <Button
          variant="ghost"
          size="sm"
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background"
          onClick={handleWishlistClick}
        >
          <Heart
            className={`h-4 w-4 ${
              isInWishlist(product.id) ? 'fill-current text-red-500' : ''
            }`}
          />
        </Button>
      </div>
      
      <div className="space-y-2">
        <h3 className="font-medium text-sm group-hover:text-primary transition-colors line-clamp-2">
          {product.name}
        </h3>
        
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium">${product.price}</span>
          {product.originalPrice && product.onSale && (
            <span className="text-xs text-muted-foreground line-through">
              ${product.originalPrice}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
