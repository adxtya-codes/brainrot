
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

const SizeGuide = () => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Size Guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Size Guide</DialogTitle>
        </DialogHeader>
        <div className="space-y-6">
          <div>
            <h3 className="font-medium mb-4">T-Shirt Measurements (inches)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2">Size</th>
                    <th className="text-left py-2">Chest</th>
                    <th className="text-left py-2">Length</th>
                    <th className="text-left py-2">Shoulder</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-2">XS</td>
                    <td className="py-2">32-34</td>
                    <td className="py-2">26</td>
                    <td className="py-2">15</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">S</td>
                    <td className="py-2">34-36</td>
                    <td className="py-2">27</td>
                    <td className="py-2">16</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">M</td>
                    <td className="py-2">38-40</td>
                    <td className="py-2">28</td>
                    <td className="py-2">17</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">L</td>
                    <td className="py-2">42-44</td>
                    <td className="py-2">29</td>
                    <td className="py-2">18</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-2">XL</td>
                    <td className="py-2">46-48</td>
                    <td className="py-2">30</td>
                    <td className="py-2">19</td>
                  </tr>
                  <tr>
                    <td className="py-2">XXL</td>
                    <td className="py-2">50-52</td>
                    <td className="py-2">31</td>
                    <td className="py-2">20</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className="text-sm text-muted-foreground space-y-2">
            <p><strong>How to measure:</strong></p>
            <p><strong>Chest:</strong> Measure around the fullest part of your chest, keeping the tape horizontal.</p>
            <p><strong>Length:</strong> Measure from the highest point of the shoulder to the desired hemline.</p>
            <p><strong>Shoulder:</strong> Measure from shoulder point to shoulder point across the back.</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SizeGuide;
