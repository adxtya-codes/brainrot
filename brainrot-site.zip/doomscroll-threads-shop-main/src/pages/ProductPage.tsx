
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowDown, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/contexts/WishlistContext';
import { useToast } from '@/hooks/use-toast';
import { useProducts } from '@/hooks/useProducts';
import SizeGuide from '@/components/SizeGuide';

const ProductPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [isZoomed, setIsZoomed] = useState(false);
  
  const { addItem } = useCart();
  const { isInWishlist, toggleItem } = useWishlist();
  const { toast } = useToast();
  const { data: products = [], isLoading, error } = useProducts();

  const product = products.find(p => p.id === id);

  const handleAddToCart = () => {
    if (!product) return;
    
    if (!selectedSize) {
      toast({
        title: "Select a size",
        description: "Please choose a size before adding to cart.",
        variant: "destructive"
      });
      return;
    }

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      size: selectedSize,
      image: product.image
    });

    toast({
      title: "Added to cart",
      description: `${product.name} (${selectedSize}) added to your cart.`
    });
  };

  const handleWishlistToggle = () => {
    if (!product) return;
    
    toggleItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image
    });

    toast({
      title: isInWishlist(product.id) ? "Removed from wishlist" : "Added to wishlist",
      description: `${product.name} ${isInWishlist(product.id) ? 'removed from' : 'added to'} your wishlist.`
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-lg">Loading product...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          ← Back
        </Button>
        <div className="text-center">
          <p className="text-lg text-red-500">Product not found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => navigate(-1)}
        className="mb-6"
      >
        ← Back
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Product Image */}
        <div className="space-y-4">
          <div 
            className={`relative overflow-hidden bg-muted/30 aspect-square cursor-zoom-in ${
              isZoomed ? 'fixed inset-0 z-50 bg-black/90 flex items-center justify-center' : ''
            }`}
            onClick={() => setIsZoomed(!isZoomed)}
          >
            <img
              src={product.image}
              alt={product.name}
              className={`object-cover transition-transform duration-300 ${
                isZoomed ? 'max-w-full max-h-full' : 'w-full h-full hover:scale-105'
              }`}
            />
            {!isZoomed && (
              <div className="absolute bottom-4 right-4 bg-black/50 text-white p-2 rounded-full">
                <ArrowDown className="h-4 w-4 rotate-45" />
              </div>
            )}
          </div>
          {isZoomed && (
            <div className="fixed top-4 right-4 z-50">
              <Button variant="outline" onClick={() => setIsZoomed(false)}>
                Close
              </Button>
            </div>
          )}
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <p className="text-2xl font-light">${product.price}</p>
          </div>

          <p className="text-muted-foreground leading-relaxed">
            {/* Use description from database if available, otherwise show a default */}
            Perfect for those who embrace the digital chaos. Made from quality materials for maximum comfort during your endless scrolling sessions.
          </p>

          {/* Size Selection */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Size</h3>
              <SizeGuide />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {product.sizes.map((size) => (
                <Button
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  onClick={() => setSelectedSize(size)}
                  className="h-12"
                >
                  {size}
                </Button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button
              onClick={handleAddToCart}
              className="w-full h-12 text-lg"
              disabled={!selectedSize}
            >
              Add to Cart - ${product.price}
            </Button>
            <Button
              variant="outline"
              onClick={handleWishlistToggle}
              className="w-full h-12"
            >
              <Heart className={`h-4 w-4 mr-2 ${isInWishlist(product.id) ? 'fill-current' : ''}`} />
              {isInWishlist(product.id) ? 'Remove from Wishlist' : 'Add to Wishlist'}
            </Button>
          </div>

          {/* Product Features */}
          <div className="space-y-3">
            <h3 className="font-medium">Features</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>• 100% Quality Materials</li>
              <li>• Pre-shrunk</li>
              <li>• Unisex fit</li>
              <li>• Screen printed design</li>
              <li>• Machine washable</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;
